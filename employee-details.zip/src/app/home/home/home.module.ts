export class HomeModule {
  key?: string | null;
  // id?:string;
  name?:string;
  email?:string;
 }

